from setuptools import setup

setup(
    name='besh',
    version='1.0',
    author='Christian Ortiz',
    py_modules=['besh'],
)